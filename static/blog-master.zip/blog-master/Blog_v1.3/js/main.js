$(function() {
    layui.carousel.render({
	    elem: '#carousel',
		width: '100%',
		arrow: 'always'
  	});
});